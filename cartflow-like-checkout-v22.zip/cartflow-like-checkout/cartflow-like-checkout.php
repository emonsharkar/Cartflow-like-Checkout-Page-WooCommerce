<?php
/**
 * Plugin Name: Cartflow like Checkout Page (WooCommerce)
 * Description: Customizes WooCommerce checkout to show only Full Name, Phone Number, Full Address, Size and Additional Note. Avoids validation errors by providing hidden country field.
 * Version: 2.2
 * Author: MD EMON SHARKAR
 * Author URI: https://github.com/emonsharkar
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Replace checkout fields with only the ones we want
 */
add_filter( 'woocommerce_checkout_fields', function( $fields ) {

    $fields['billing'] = [
        'billing_full_name' => [
            'type'        => 'text',
            'label'       => __('Full Name', 'minimal-four-field'),
            'required'    => true,
            'class'       => ['form-row-wide'],
            'priority'    => 10,
            'autocomplete'=> 'name',
            'placeholder' => __('e.g. Mohammad Rahim', 'minimal-four-field'),
        ],
        'billing_mobile' => [
            'type'        => 'tel',
            'label'       => __('Mobile Number', 'minimal-four-field'),
            'required'    => true,
            'class'       => ['form-row-wide'],
            'priority'    => 20,
            'autocomplete'=> 'tel',
            'placeholder' => __('e.g. 01XXXXXXXXX', 'minimal-four-field'),
            'validate'    => ['phone'],
        ],
        'billing_full_address' => [
            'type'        => 'textarea',
            'label'       => __('Full Address', 'minimal-four-field'),
            'required'    => true,
            'class'       => ['form-row-wide'],
            'priority'    => 30,
            'placeholder' => __('House, Road, Area, City, Post Code', 'minimal-four-field'),
        ],
        'billing_size' => [
            'type'        => 'select',
            'label'       => __('Size', 'minimal-four-field'),
            'required'    => true,
            'class'       => ['form-row-first'],
            'priority'    => 40,
            'options'     => [
                ''   => __('Select size', 'minimal-four-field'),
                'M'  => 'M',
                'L'  => 'L',
                'XL' => 'XL',
                'XXL'=> 'XXL',
            ],
        ],
    ];

    // Remove shipping + notes completely
    $fields['shipping'] = [];
    $fields['order']    = [];

    return $fields;
}, 999 );

/**
 * Validate
 */
add_action( 'woocommerce_checkout_process', function() {
    if ( isset($_POST['billing_mobile']) ) {
        $mobile = preg_replace('/\D+/', '', $_POST['billing_mobile']);
        if ( strlen($mobile) < 10 ) {
            wc_add_notice( __('Please enter a valid mobile number.' , 'minimal-four-field'), 'error' );
        }
    }
    if ( isset($_POST['billing_size']) && empty($_POST['billing_size']) ) {
        wc_add_notice( __('Please select a size.', 'minimal-four-field'), 'error' );
    }
});

/**
 * Save fields to order
 */
add_action( 'woocommerce_checkout_create_order', function( $order ) {
    $map = [
        'billing_full_name'   => '_billing_full_name',
        'billing_mobile'      => '_billing_mobile',
        'billing_full_address'=> '_billing_full_address',
        'billing_size'        => '_billing_size',
    ];

    foreach ( $map as $post_key => $meta_key ) {
        if ( isset($_POST[$post_key]) ) {
            $val = ( $post_key === 'billing_full_address' )
                ? sanitize_textarea_field( wp_unslash($_POST[$post_key]) )
                : sanitize_text_field( wp_unslash($_POST[$post_key]) );
            $order->update_meta_data( $meta_key, $val );
        }
    }

    // Map name + address into WC defaults
    if ( isset($_POST['billing_full_name']) ) {
        $full = trim( wp_unslash($_POST['billing_full_name']) );
        $parts = preg_split('/\s+/', $full);
        $last  = array_pop($parts);
        $first = implode(' ', $parts);
        if ( empty($first) ) { $first = $full; $last = ''; }
        $order->set_billing_first_name( $first );
        $order->set_billing_last_name( $last );
    }
    if ( isset($_POST['billing_full_address']) ) {
        $order->set_billing_address_1( sanitize_textarea_field( wp_unslash($_POST['billing_full_address']) ) );
    }
}, 10, 1 );

/**
 * Show in admin
 */
add_action( 'woocommerce_admin_order_data_after_billing_address', function( $order ) {
    echo '<div class="address">';
    echo '<p><strong>Full Name:</strong> ' . esc_html( $order->get_meta('_billing_full_name') ) . '</p>';
    echo '<p><strong>Mobile:</strong> ' . esc_html( $order->get_meta('_billing_mobile') ) . '</p>';
    echo '<p><strong>Full Address:</strong><br>' . nl2br( esc_html( $order->get_meta('_billing_full_address') ) ) . '</p>';
    echo '<p><strong>Size:</strong> ' . esc_html( $order->get_meta('_billing_size') ) . '</p>';
    echo '</div>';
}, 10 );

/**
 * Add to emails
 */
add_filter( 'woocommerce_email_order_meta_fields', function( $fields, $sent_to_admin, $order ) {
    $fields['billing_full_name'] = [
        'label' => __('Full Name', 'minimal-four-field'),
        'value' => $order->get_meta('_billing_full_name'),
    ];
    $fields['billing_mobile'] = [
        'label' => __('Mobile Number', 'minimal-four-field'),
        'value' => $order->get_meta('_billing_mobile'),
    ];
    $fields['billing_full_address'] = [
        'label' => __('Full Address', 'minimal-four-field'),
        'value' => $order->get_meta('_billing_full_address'),
    ];
    $fields['billing_size'] = [
        'label' => __('Size', 'minimal-four-field'),
        'value' => $order->get_meta('_billing_size'),
    ];
    return $fields;
}, 10, 3 );