<?php
/**
 * Plugin Name: Cartflow like Checkout Page (WooCommerce)
 * Description: Customizes WooCommerce checkout to show only Full Name, Phone Number, Full Address, and Additional Note. Avoids validation errors by providing hidden country field.
 * Version: 1.6
 * Author: MD EMON SHARKAR
 * Author URI: https://github.com/emonsharkar
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Customize checkout fields
add_filter( 'woocommerce_checkout_fields', 'cartflow_like_custom_checkout_fields_v16' );
function cartflow_like_custom_checkout_fields_v16( $fields ) {

    $fields['billing'] = array(
        'billing_first_name' => array(
            'label'       => 'Full Name',
            'required'    => true,
            'class'       => array('form-row-wide'),
            'priority'    => 10,
            'custom_attributes' => array(
                'pattern' => '^[A-Za-z ]+$',
                'title'   => 'Only alphabets are allowed'
            )
        ),
        'billing_phone' => array(
            'label'       => 'Phone Number',
            'required'    => true,
            'class'       => array('form-row-wide'),
            'priority'    => 20,
            'custom_attributes' => array(
                'pattern' => '^0[0-9]{9,}$',
                'title'   => 'Only digits allowed starting with 0'
            )
        ),
        'billing_address_1' => array(
            'label'       => 'House/Road/Area + ZIP Code',
            'required'    => true,
            'class'       => array('form-row-wide'),
            'priority'    => 30
        ),
        'billing_country' => array(
            'type'        => 'hidden',
            'label'       => false,
            'required'    => true,
            'default'     => 'BD'
        )
    );

    $fields['order'] = array(
        'order_comments' => array(
            'label'       => 'Additional Note',
            'required'    => false,
            'class'       => array('form-row-wide'),
            'priority'    => 40
        )
    );

    return $fields;
}

// Prevent errors for hidden fields
add_action( 'woocommerce_after_checkout_validation', 'cartflow_like_clear_unwanted_validation_v16', 10, 2 );
function cartflow_like_clear_unwanted_validation_v16( $data, $errors ) {
    $unwanted = array( 'billing_city', 'billing_postcode', 'billing_state' );
    foreach ( $unwanted as $field ) {
        if ( isset( $errors->errors[ $field ] ) ) {
            unset( $errors->errors[ $field ] );
        }
    }
}

// Hide remaining default address fields
add_action( 'wp_enqueue_scripts', 'cartflow_like_hide_default_fields_v16' );
function cartflow_like_hide_default_fields_v16() {
    if ( is_checkout() ) {
        wp_add_inline_style( 'woocommerce-layout', '
            .woocommerce-billing-fields__field-wrapper .form-row:not(.form-row-wide) { display: none !important; }
            select#billing_country, .billing_country_field { display: none !important; }
        ' );
    }
}

// Prepend product image to product name in order review (Your Order section)
add_filter( 'woocommerce_cart_item_name', function( $product_name, $cart_item, $cart_item_key ) {
    $product = $cart_item['data'];
    if ( $product && is_object( $product ) ) {
        $thumbnail = $product->get_image( 'woocommerce_thumbnail', array( 'style' => 'border-radius:10px; margin-right:8px;' ) );
        $product_name = $thumbnail . ' ' . $product_name;
    }
    return $product_name;
}, 10, 3 );

